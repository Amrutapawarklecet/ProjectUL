package com.department.DepartmentCurdOperations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


//This is the key annoation of application.It is the staring point of main application.
@SpringBootApplication
public class DepartmentCurdOperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepartmentCurdOperationsApplication.class, args);
	}

}
