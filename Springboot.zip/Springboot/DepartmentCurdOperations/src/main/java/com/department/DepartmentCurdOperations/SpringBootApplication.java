package DepartmentCurdOperations.src.main.java.com.department.DepartmentCurdOperations;

public @interface SpringBootApplication {
}
